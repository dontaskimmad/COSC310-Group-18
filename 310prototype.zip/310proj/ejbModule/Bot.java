import java.util.Scanner;
public class Bot {
	public Bot() {
	}
	static int[] computeLspTable(String pattern) {
	    int[] lsp = new int[pattern.length()];
	    lsp[0] = 0;
	    for (int i = 1; i < pattern.length(); i++) {
	        int j = lsp[i - 1];
	        while (j > 0 && pattern.charAt(i) != pattern.charAt(j))
	            j = lsp[j - 1];
	        if (pattern.charAt(i) == pattern.charAt(j))
	            j++;
	        lsp[i] = j;
	    }
	    return lsp;
	}
	static int search(String pattern, String text) {
	    int[] lsp = computeLspTable(pattern);
	    int j = 0;  
	    for (int i = 0; i < text.length(); i++) {
	        while (j > 0 && text.charAt(i) != pattern.charAt(j)) {
	            j = lsp[j - 1]; 
	        }
	        if (text.charAt(i) == pattern.charAt(j)) {
	            j++;
	            if (j == pattern.length())
	                return i - (j - 1);
	        }
	    }
	    return -1; 
	}
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("whats your name?");
		String inp=input.nextLine();
		System.out.println(inp+", I need your help");
		String inp1=input.nextLine();
		String pat="bro";
		if (search(inp1,pat)!=-1) {
			System.out.println("yay");
		}
	}
}
