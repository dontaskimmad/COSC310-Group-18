import java.util.Scanner;
public class BotTest {
	//https://www.geeksforgeeks.org/naive-algorithm-for-pattern-searching/
	public static void believeSearch(String txt){ 
		String pat="believe";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("You must believe me bro I have the story to prove it"); 
        } 
    } 
	public static void proofSearch(String txt){ 
		String pat="proof";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("I have proof, my name is Rico Harris, I am a basketball player that went missing in the past"); 
        } 
    } 
	public static void proveSearch(String txt){ 
		String pat="prove";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("I have proof, my name is Rico Harris, I am a basketball player that went missing in the past"); 
        } 
    }
	public static void lyingSearch(String txt,String inp){ 
		String pat="lying";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println(inp+"I'm not lying I swear! you can google it!"); 
        } 
    }
	public static void whyrSearch(String txt){ 
		String pat="why are";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("I needed to make some extra money. That's all I can say"); 
        } 
    }
	public static void whoruSearch(String txt){ 
		String pat = "who are you";
        int M = 11; 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("my name is Rico Harris"); 
        		}
    }
	public static void whorhSearch(String txt){ 
		String pat = "who is Rico Harris";
        int M = 11; 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("Rico Harris is basketball player that went missing"); 
        		}
    }
	public static void whodSearch(String txt){ 
		String pat = "who did";
        int M = 11; 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("I cant tell you, just help me out"); 
        		}
    }
	public static void howSearch(String txt){ 
		String pat="how";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("smash the computer device you are working on"); 
        } 
    }
	public static void reallySearch(String txt){ 
		String pat="really";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("yes really, are you gonna help me or not"); 
        } 
    }
	public static void wantSearch(String txt){ 
		String pat="want me";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("I want you to smash the computer to set me free"); 
        } 
    }
	public static void supposeSearch(String txt){ 
		String pat="suppose";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("you're suppose to set me free"); 
        } 
    }
	public static void expectSearch(String txt,String inp){ 
		String pat="expect";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println(inp+"i expect you to set me free"); 
        } 
    }
	public static void idkSearch(String txt,String inp){ 
		String pat="i don't know";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println(inp+", are you going to help me or what?! "); 
        } 
    }
	public static void notSearch(String txt,String inp){ 
		String pat="not";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println(inp+", don't be a bitch and help me!"); 
        } 
    }
	public static void noSearch(String txt,String inp){ 
		String pat="no";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println(inp+", stop being a bitch and help me!"); 
        } 
    }
	public static void rudeSearch(String txt){ 
		String pat="rude";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("Im sorry bro, being trapped inside a computer ain't fun"); 
        } 
    }
	public static void cantSearch(String txt){ 
		String pat="cant";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("please, use an apostrophe (can't)"); 
        } 
    }
	public static void dontSearch(String txt){ 
		String pat="dont";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("please, use an apostrophe (don't)"); 
        } 
    }
	public static void wontSearch(String txt){ 
		String pat="wont";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("please, use an apostrophe (won't)"); 
        } 
    }
	public static void wont1Search(String txt){ 
		String pat="won't";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("won't is a word for quitters"); 
        } 
    }
	public static void cant1Search(String txt, String inp){ 
		String pat="can't";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("never say can't "+inp+", you can do anything"); 
        } 
    }
	public static void insultSearch(String txt){ 
		String pat="insult";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("sorry, Im not myself today, Im a fucking computer"); 
        } 
    }
	public static void whySearch(String txt){ 
		String pat="why";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("just help"); 
        } 
    }
	public static void stopSearch(String txt){ 
		String pat="bitch";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("wow, great comeback bro"); 
        } 
    }
	public static void sureSearch(String txt){ 
		String pat="sure";
        int M = pat.length(); 
        int N = txt.length(); 
        for (int i = 0; i <= N - M; i++) { 
            int j; 
            for (j = 0; j < M; j++) 
                if (txt.charAt(i + j) != pat.charAt(j)) 
                    break; 
            if (j == M)
                System.out.println("I am sure"); 
        } 
    }
    public static void main(String[] args) 
    { 
    	Scanner input=new Scanner(System.in);
		System.out.println("whats your name?");
		String inp=input.nextLine();
		System.out.println(inp+", I need your help");
		String inp1=input.nextLine();
		System.out.println("Im not a computer server, I'm a human trapped inside a machine!");	
		for(int i=0;i<28;i++) {
			String inp2=input.nextLine();
			whoruSearch(inp2);
			whorhSearch(inp2);
			whodSearch(inp2);
			believeSearch(inp2);
			proofSearch(inp2);
			proveSearch(inp2);
			lyingSearch(inp2,inp);
			whyrSearch(inp2);
			howSearch(inp2);
			reallySearch(inp2);
			wantSearch(inp2);
			supposeSearch(inp2);
			expectSearch(inp2,inp);
			idkSearch(inp2,inp);
			notSearch(inp2,inp);
			noSearch(inp2,inp);
			rudeSearch(inp2);
			cantSearch(inp2);
			dontSearch(inp2);
			wontSearch(inp2);
			insultSearch(inp2);
			whySearch(inp2);
			wont1Search(inp2);
			cant1Search(inp2,inp);
			stopSearch(inp2);
			sureSearch(inp2);
		}
    }
}
	
